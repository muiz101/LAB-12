<!DOCTYPE html>

<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jsgrid/1.4.1/jsgrid.min.css" />
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jsgrid/1.4.1/jsgrid-theme.min.css" />

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jsgrid/1.4.1/jsgrid.min.js"></script>
    <link type="text/css" rel="stylesheet" href="jsgrid.min.css" />
    <link type="text/css" rel="stylesheet" href="jsgrid-theme.min.css" />

    <script type="text/javascript" src="jsgrid.min.js"></script>

</head>
<body>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
<div><h1>Trial Balance B/F</h1>
<div id="jsGrid"></div>



                <div>

<script>
    var clients = [


    ];

    var countries = [
        { Name: "", Id: 0 },
        { Name: "Debit", Id:1},
        { Name: "Credit", Id:2},

    ];

    $("#jsGrid").jsGrid({
        width: "100%",
        height: "400px",

        inserting: true,
        editing: true,
        sorting: true,
        paging: true,

        data: clients,

        fields: [
            { name: "Year", type: "text", width: 150, validate: "required" },
            { name: "COA", type: "number", width: 50 },
            { name: "Description", type: "text", width: 200 },
            { name: "Debit/Credit", type: "select", items: countries, valueField: "Id", textField: "Name" },
            { name: "Amount", type: "text", title: "Amount", width:50 },
            { type: "control" }
        ]
    });
</script>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>